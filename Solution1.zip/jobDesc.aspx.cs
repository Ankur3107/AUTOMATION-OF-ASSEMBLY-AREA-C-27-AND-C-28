﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Data;

public partial class jobDesc : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataView dv = (DataView)(sdcjobs.Select(DataSourceSelectArguments.Empty));
        DataView dvm = (DataView)(sdcmac.Select(DataSourceSelectArguments.Empty));
        DataView dvl = (DataView)(sdcloc.Select(DataSourceSelectArguments.Empty));
        DataView dvf = (DataView)(sdcfin.Select(DataSourceSelectArguments.Empty));

        dvm.Sort = "machineID";
        dvl.Sort = "Id";
        jid.Text = Request.QueryString["jid"].ToString();
        delay.Text = (Convert.ToInt32(dv.Table.Rows[0]["t_delay"])==0)?"ON TIME": dv.Table.Rows[0]["t_delay"].ToString()+" DAYS";
        delay.ForeColor = (Convert.ToInt32(dv.Table.Rows[0]["t_delay"]) == 0) ?System.Drawing.Color.Green:System.Drawing.Color.Red;
        m.Text = dv.Table.Rows[0]["machineID"].ToString();
        aa.Text = dvl.Table.Rows[dvl.Find(dvm.Table.Rows[dvm.Find(dv.Table.Rows[0]["machineID"].ToString())]["locationID"].ToString())]["assembly"].ToString();
        aa.PostBackUrl = "svC" + aa.Text.TrimStart('c') + ".aspx";
        s.Text = (Convert.ToDateTime(dv.Table.Rows[0]["startdate"])).ToShortDateString();
        if(dv.Table.Rows[0]["over"].ToString()=="1") en.Text= (Convert.ToDateTime(dv.Table.Rows[0]["enddate"])).ToShortDateString();

        jad.Text = s.Text;
        for (int i = 0; i < dvf.Table.Rows.Count; i++)
        {
            TableRow tr = new TableRow();

            TableCell c1 = new TableCell();
            TableCell c2 = new TableCell();
            TableCell c3 = new TableCell();

            DataView dvp = (DataView)(sdcphases.Select(DataSourceSelectArguments.Empty));
            dvp.Sort="phaseORDER";

            c1.Text = dvp.Table.Rows[dvp.Find(dvf.Table.Rows[i]["phaseID"].ToString())]["phaseNAME"] + " COMPLETED";
            c2.Text = dvf.Table.Rows[i]["timestamp"].ToString();

            tr.Cells.Add(c1);
            tr.Cells.Add(c2);
            c1.BorderWidth = 1;
            c2.BorderWidth = 1;
           tr.Cells.Add(c3);
            c3.BorderWidth = 1;
            c3.Text = (Convert.ToInt32(dvf.Table.Rows[i]["delay"]) == 0) ?"ON TIME":"Delay by "+ Convert.ToInt32(dvf.Table.Rows[i]["delay"])+" days";
            c3.ForeColor = (Convert.ToInt32(dvf.Table.Rows[i]["delay"]) == 0) ?System.Drawing.Color.Green: System.Drawing.Color.Red;
            tjd.Rows.Add(tr);
        }

        foreach (TableRow tr in tjd.Rows)
        {
            foreach (TableCell tc in tr.Cells)
            {
                tc.Attributes.CssStyle.Add("text-align", "center");
            }
        }
    }
   
}