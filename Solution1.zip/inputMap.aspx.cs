﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;
using System.Data.SqlClient;

public partial class inputMap : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["mid"] == null)
            Response.Redirect("assembly.aspx");

        machineID.Text = Request.QueryString["mid"].ToString();
        machineID.PostBackUrl="macDesc.aspx?mid="+ Request.QueryString["mid"].ToString();
        DataView dvp = (DataView)(SqlDataSourcephases.Select(DataSourceSelectArguments.Empty));
        DataView dvj = (DataView)(SqlDataSourcejob.Select(DataSourceSelectArguments.Empty));
        DataView dvc = (DataView)(SqlDataSourcecustomer.Select(DataSourceSelectArguments.Empty));
        DataView dvf = (DataView)(SqlDataSourcefinished.Select(DataSourceSelectArguments.Empty));
        h2.Value = dvj.Table.Rows[0]["jobID"].ToString();
        dvc.Sort = "custID";
        jid.Value = dvj.Table.Rows[0]["jobID"].ToString();
        jobID.Text = dvj.Table.Rows[0]["jobID"].ToString();
        jobID.PostBackUrl="jobDesc.aspx?jid="+ dvj.Table.Rows[0]["jobID"].ToString();
        customer.Text = dvc.Table.Rows[dvc.Find(dvj.Table.Rows[0]["customerID"].ToString())]["custName"].ToString();
        customer.PostBackUrl = "custDesc.aspx?cid=" + dvj.Table.Rows[0]["customerID"].ToString();
        for (int i = 0; i < dvp.Table.Rows.Count; i++)
        {
            foreach (TableRow tr in phasetable.Rows)
            {
                TableCell c = new TableCell();
                Button b = new Button();
                b.Width = 35;
                b.Height = 50;
                b.Attributes.CssStyle.Add("CssClass", "btn-info");
                b.BackColor = System.Drawing.Color.Gray;
                b.ForeColor = System.Drawing.Color.White;
                b.ID = dvp.Table.Rows[i]["phaseORDER"].ToString();
                b.Text = dvp.Table.Rows[i]["phaseORDER"].ToString();
                b.Click += B_Click;
                b.CssClass = "but";
                c.Controls.Add(b);
                
                c.ToolTip = dvp.Table.Rows[i]["phaseNAME"].ToString();
                //if (b.Text == dvj.Table.Rows[0]["currentPhaseID"].ToString()) b.BackColor = System.Drawing.Color.Blue;
                for (int j = 0; j < dvf.Table.Rows.Count; j++)
                {
                    if ((dvj.Table.Rows[0]["jobID"].ToString() == dvf.Table.Rows[j]["jobID"].ToString()) && (b.Text == dvf.Table.Rows[j]["phaseID"].ToString()))
                    {
                        b.BackColor = System.Drawing.Color.Green;
                        b.Enabled = false;
                    }
                }
                tr.Cells.Add(c);
            }
        }
        

    }

    private void B_Click(object sender, EventArgs e)
    {
        Button ButtonPhase = (Button)sender;
        h.Value = ButtonPhase.ID.ToString();
        DataView dvph = (DataView)(SqlDataSourcephases.Select(DataSourceSelectArguments.Empty));
        dvph.Sort = "phaseORDER";
        hh.Value = dvph.Table.Rows[dvph.Find(ButtonPhase.ID)]["phaseORDER"].ToString();
        SqlDataSourcefinished.Insert();

        //UpdateCurrentPhase(ButtonPhase);



        //change here
        DataView dj = (DataView)(sdcjdelay.Select(DataSourceSelectArguments.Empty));
        DataView df = (DataView)(sdcfdelay.Select(DataSourceSelectArguments.Empty));
        if(df!=null)
        df.Sort = "phaseID";
        DateTime dta = DateTime.Now;
        DateTime dtb = (df == null) ?Convert.ToDateTime(dj.Table.Rows[0]["startdate"]):Convert.ToDateTime(df.Table.Rows[df.Find(dj.Table.Rows[0]["currentPhaseID"])]["timestamp"]);
        double timetaken = (dta - dtb).TotalDays;
        init.Value = dtb.ToString();
        end.Value = dta.ToString();
        for (DateTime i = dtb; i <= dta; i=i.AddDays(1))
        {
            if ((i.DayOfWeek == DayOfWeek.Saturday) || (i.DayOfWeek == DayOfWeek.Sunday))
                timetaken = timetaken - 1;
        }
        DataView dh = (DataView)(sdh.Select(DataSourceSelectArguments.Empty));
        timetaken = timetaken - dh.Table.Rows.Count;
        timetaken *= 7.5;
        delay.Value=Convert.ToInt32((Convert.ToDouble(dj.Table.Rows[0]["t_delay"])*7.5 + timetaken- Convert.ToDouble(dvph.Table.Rows[dvph.Find(ButtonPhase.ID)]["phaseDURATION"]))/7.5).ToString();
        dtn.Value = dta.ToString();
        cp.Value = dj.Table.Rows[0]["currentPhaseID"].ToString();
        sdcfdelay.Update();
        sdcjdelay.Update();


        sdj2.Update();
        DataView dvj = (DataView)(SqlDataSourcejob.Select(DataSourceSelectArguments.Empty));
        if (dvj.Table.Rows[0]["currentPhaseId"].ToString() == "370")
        {
            DateTime dt = DateTime.Now;
            h5.Value = dt.ToString();
            sdj3.Update();
            sdcm.Update();
            Response.Redirect("jobOver.aspx?jid=" + dvj.Table.Rows[0]["jobID"].ToString());
        }
        Response.Redirect("inputMap.aspx?mid=" + Request.QueryString["mid"].ToString());
    }

    /*private void UpdateCurrentPhase(Button ButtonPhase)
    {
        string cs = WebConfigurationManager.ConnectionStrings["automationConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);
        string qry = "SELECT * FROM job where machineID=@machineID and jobID=@jobID";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.Parameters.AddWithValue("@machineID", machineID.Text);
        cmd.Parameters.AddWithValue("@jobID", jid.Value);
        con.Open();
        SqlDataReader rd = cmd.ExecuteReader();
        int delay;
        if (rd.HasRows)
        {
            rd.Read();
            delay = Convert.ToInt32(rd["t_delay"].ToString());
            Response.Write(delay.ToString());
        }
        con.Close();
        DateTime NewCurrentPhaseTime = DateTime.Now;
        cmd.CommandText = "SELECT * FROM phase where phaseID=@phaseID";
        cmd.Parameters.AddWithValue("@phaseID", ButtonPhase.ID);
    }*/
}