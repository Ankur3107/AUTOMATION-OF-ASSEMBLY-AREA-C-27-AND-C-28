﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class job : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin"] == null)
            Server.Transfer("admin.aspx");
        else
            admin.Text = "ADMIN " + Session["admin"].ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string cs = WebConfigurationManager.ConnectionStrings["automationConnectionString"].ConnectionString;
        SqlConnection conn = new SqlConnection(cs);
        conn.Open();

        string cmd = "INSERT INTO job(machineID,customerID,groupleaderID,worker2ID) VALUES(@mId,@cId,@gId,@wId)";
        SqlCommand command = new SqlCommand(cmd, conn);

        command.Parameters.AddWithValue("@mId", DropDownList1.SelectedValue);
        command.Parameters.AddWithValue("@cId", DropDownList2.SelectedValue);
        command.Parameters.AddWithValue("@gId", ddlGroupLeader.SelectedValue);
        command.Parameters.AddWithValue("@wId", DropDownList4.SelectedValue);
        //command.Parameters.AddWithValue("@cpId", DropDownList5.SelectedValue);

        command.ExecuteNonQuery();

        conn.Close();
        GridView1.Sort("machineID", SortDirection.Ascending);

        SqlDataSourcemachine.Update();

        DataView dvj = (DataView)(sdcj.Select(DataSourceSelectArguments.Empty));
        DataView dvw = (DataView)(sdcw.Select(DataSourceSelectArguments.Empty));
        dvw.Sort = "workerID";
        for (int i = 0; i < dvj.Table.Rows.Count; i++)
        {
            h.Value = dvj.Table.Rows[i][5].ToString();
            sdcw.Update();
            h.Value = dvj.Table.Rows[i][6].ToString();
            sdcw.Update();

        }


        Response.Redirect("job.aspx");
    }

}