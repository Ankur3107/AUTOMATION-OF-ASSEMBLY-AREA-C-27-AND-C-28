﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class jobOver : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["jid"] == null) Response.Redirect("assembly.aspx");
        jo.Text = Request.QueryString["jid"].ToString();

        DataView dvj = (DataView)(sj.Select(DataSourceSelectArguments.Empty));
        h1.Value = dvj.Table.Rows[0]["groupleaderID"].ToString();
        sw.Update();
        h1.Value = dvj.Table.Rows[0]["worker2ID"].ToString();
        sw.Update();

    }
}