﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class workDesc : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["statsViewer"] == null) Response.Redirect("svLogin.aspx");

        DataView dvw = (DataView)(sdcw.Select(DataSourceSelectArguments.Empty));
        DataView dvj1 = (DataView)(sdcj1.Select(DataSourceSelectArguments.Empty));
        DataView dvj2 = (DataView)(sdcj2.Select(DataSourceSelectArguments.Empty));

        wl.Text = dvw.Table.Rows[0][1].ToString();
        wid.Text = dvw.Table.Rows[0][0].ToString();
        jo.Text = Convert.ToDateTime(dvw.Table.Rows[0][4]).ToShortDateString();
        gl.Text = (dvw.Table.Rows[0][1].ToString() == dvw.Table.Rows[0][2].ToString()) ?"-": dvw.Table.Rows[0][2].ToString();
        noj.Text = (dvj1.Table.Rows.Count + dvj2.Table.Rows.Count).ToString();
        if(gl.Text=="-")
        {
            for (int i = 0; i < dvj1.Table.Rows.Count; i++)
            {
                TableRow tr = new TableRow();
                twd.Rows.Add(tr);
                TableCell c1 = new TableCell();
                TableCell c2 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                c1.BorderWidth = 1;
                c2.BorderWidth = 1;
                c3.BorderWidth = 1;
                c4.BorderWidth = 1;
                tr.Cells.Add(c1);
                tr.Cells.Add(c2);
                tr.Cells.Add(c3);
                tr.Cells.Add(c4);
                LinkButton l1 = new LinkButton();
                c1.Controls.Add(l1);
                l1.Text = dvj1.Table.Rows[i][0].ToString();
                l1.PostBackUrl = "jobDesc.aspx?jid=" + l1.Text;
                c2.Text = Convert.ToDateTime(dvj1.Table.Rows[i][3]).ToShortDateString();
                c3.Text = (dvj1.Table.Rows[i][9].ToString()=="1") ? Convert.ToDateTime(dvj1.Table.Rows[i][4]).ToShortDateString() :"";
                c4.Text = (Convert.ToInt32(dvj1.Table.Rows[i]["t_delay"]) == 0) ? "COMPLETED ON TIME" : "DELAYED BY " + dvj1.Table.Rows[i]["t_delay"].ToString() + " DAYS";
                c4.ForeColor = (Convert.ToInt32(dvj1.Table.Rows[i]["t_delay"]) == 0) ? System.Drawing.Color.Green : System.Drawing.Color.Red;

            }
        }
        else
        {
            for (int i = 0; i < dvj2.Table.Rows.Count; i++)
            {
                TableRow tr = new TableRow();
                twd.Rows.Add(tr);
                TableCell c1 = new TableCell();
                TableCell c2 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                c1.BorderWidth = 1;
                c2.BorderWidth = 1;
                c3.BorderWidth = 1;
                c4.BorderWidth = 1;
                tr.Cells.Add(c1);
                tr.Cells.Add(c2);
                tr.Cells.Add(c3);
                tr.Cells.Add(c4);
                LinkButton l1 = new LinkButton();
                c1.Controls.Add(l1);
                l1.Text = dvj2.Table.Rows[i][0].ToString();
                l1.PostBackUrl = "jobDesc.aspx?jid=" + l1.Text;
                c2.Text = Convert.ToDateTime(dvj2.Table.Rows[i][3]).ToShortDateString();
                c3.Text = (dvj2.Table.Rows[i][9].ToString() == "1") ? Convert.ToDateTime(dvj2.Table.Rows[i][4]).ToShortDateString() : "";
                c4.Text = (Convert.ToInt32(dvj2.Table.Rows[i]["t_delay"]) == 0) ? "COMPLETED ON TIME" : "DELAYED BY " + dvj2.Table.Rows[i]["t_delay"].ToString() + " DAYS";
                c4.ForeColor = (Convert.ToInt32(dvj2.Table.Rows[i]["t_delay"]) == 0) ? System.Drawing.Color.Green : System.Drawing.Color.Red;

            }
        }
        foreach (TableRow tr in twd.Rows)
        {
            foreach (TableCell tc in tr.Cells)
            {
                tc.Attributes.CssStyle.Add("text-align", "center");
            }
        }

    }
}